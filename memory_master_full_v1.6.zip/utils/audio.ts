class AudioManager {
  private ctx: AudioContext | null = null;
  private enabled: boolean = true;
  toggle(v: boolean) { this.enabled = v; }
  private play(f: number, t: OscillatorType, d: number) {
    if (!this.enabled) return;
    const c = this.ctx || (this.ctx = new AudioContext());
    const o = c.createOscillator();
    const g = c.createGain();
    o.type = t; o.frequency.setValueAtTime(f, c.currentTime);
    g.gain.setValueAtTime(0.1, c.currentTime);
    g.gain.exponentialRampToValueAtTime(0.01, c.currentTime + d);
    o.connect(g); g.connect(c.destination);
    o.start(); o.stop(c.currentTime + d);
  }
  playFlip() { this.play(440, 'sine', 0.1); }
  playMatch() { this.play(523, 'sine', 0.1); setTimeout(() => this.play(659, 'sine', 0.2), 50); }
  playMiss() { this.play(220, 'triangle', 0.2); }
  playWin() { [523, 659, 783, 1046].forEach((f, i) => setTimeout(() => this.play(f, 'sine', 0.4), i * 150)); }
}
export const audio = new AudioManager();
export const decode = (b: string) => Uint8Array.from(atob(b), c => c.charCodeAt(0));
export const encode = (b: Uint8Array) => btoa(String.fromCharCode(...b));
export async function decodeAudioData(d: Uint8Array, c: AudioContext, s: number, ch: number) {
  const i16 = new Int16Array(d.buffer);
  const fc = i16.length / ch;
  const b = c.createBuffer(ch, fc, s);
  for (let n = 0; n < ch; n++) {
    const cd = b.getChannelData(n);
    for (let i = 0; i < fc; i++) cd[i] = i16[i * ch + n] / 32768;
  }
  return b;
}