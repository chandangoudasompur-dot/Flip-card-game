import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Difficulty, CardData, GameStats } from './types';
import { LEVEL_CONFIGS, EMOJI_SETS } from './constants';
import { audio, encode, decode, decodeAudioData } from './utils/audio';
import Card from './components/Card';
import StatsPanel from './components/StatsPanel';
import Menu from './components/Menu';
import ResultModal from './components/ResultModal';
import VoiceOverlay from './components/VoiceOverlay';
import { GoogleGenAI, Modality, Type } from '@google/genai';

const App = () => {
  const [gameState, setGameState] = useState('menu');
  const [difficulty, setDifficulty] = useState(Difficulty.EASY);
  const [category, setCategory] = useState('ANIMALS');
  const [cards, setCards] = useState([]);
  const [flippedIndices, setFlippedIndices] = useState([]);
  const [stats, setStats] = useState({ score: 0, attempts: 0, timeSeconds: 0, matches: 0, totalPairs: 0 });
  const [isVoiceActive, setIsVoiceActive] = useState(false);
  const [transcription, setTranscription] = useState('');
  const sessionRef = useRef(null);
  const timerRef = useRef(null);
  const nextStartTimeRef = useRef(0);

  const cardsRef = useRef(cards);
  const flippedRef = useRef(flippedIndices);
  useEffect(() => { cardsRef.current = cards; }, [cards]);
  useEffect(() => { flippedRef.current = flippedIndices; }, [flippedIndices]);

  const stopVoice = useCallback(() => {
    if (sessionRef.current) { sessionRef.current.close(); sessionRef.current = null; }
    setIsVoiceActive(false); setTranscription('');
  }, []);

  const startGame = useCallback(() => {
    stopVoice();
    const config = LEVEL_CONFIGS[difficulty];
    const totalPairs = (config.rows * config.cols) / 2;
    const emojiSet = EMOJI_SETS[category] || EMOJI_SETS.ANIMALS;
    const selectedSymbols = [...emojiSet].sort(() => Math.random() - 0.5).slice(0, totalPairs);
    const initialCards = [];
    selectedSymbols.forEach((symbol, index) => {
      initialCards.push({ symbol, isFlipped: false, isMatched: false, pairId: index, id: \`p${index}a\` });
      initialCards.push({ symbol, isFlipped: false, isMatched: false, pairId: index, id: \`p${index}b\` });
    });
    setCards(initialCards.sort(() => Math.random() - 0.5));
    setFlippedIndices([]);
    setStats({ score: 0, attempts: 0, timeSeconds: 0, matches: 0, totalPairs });
    setGameState('playing');
    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = setInterval(() => setStats(p => ({ ...p, timeSeconds: p.timeSeconds + 1 })), 1000);
  }, [difficulty, category, stopVoice]);

  const handleCardClick = useCallback((index) => {
    const currentCards = cardsRef.current;
    const currentFlipped = flippedRef.current;
    if (currentFlipped.length >= 2 || currentCards[index].isFlipped || currentCards[index].isMatched) return;
    audio.playFlip();
    const newFlipped = [...currentFlipped, index];
    setFlippedIndices(newFlipped);
    setCards(prev => {
      const updated = [...prev];
      updated[index] = { ...updated[index], isFlipped: true };
      return updated;
    });
    if (newFlipped.length === 2) {
      const [i1, i2] = newFlipped;
      setStats(p => ({ ...p, attempts: p.attempts + 1 }));
      if (currentCards[i1].pairId === currentCards[i2].pairId) {
        setTimeout(() => {
          audio.playMatch();
          setCards(prev => prev.map((c, idx) => (idx === i1 || idx === i2) ? { ...c, isMatched: true, isFlipped: false } : c));
          setFlippedIndices([]);
          setStats(p => {
            const nextMatches = p.matches + 1;
            if (nextMatches === p.totalPairs) { clearInterval(timerRef.current); audio.playWin(); setGameState('won'); stopVoice(); }
            return { ...p, matches: nextMatches, score: p.score + 100 };
          });
        }, 500);
      } else {
        setTimeout(() => {
          audio.playMiss();
          setCards(prev => prev.map((c, idx) => (idx === i1 || idx === i2) ? { ...c, isFlipped: false } : c));
          setFlippedIndices([]);
        }, 1000);
      }
    }
  }, [stopVoice]);

  const startVoice = async () => {
    if (isVoiceActive) return;
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const inputCtx = new AudioContext({ sampleRate: 16000 });
      const outputCtx = new AudioContext({ sampleRate: 24000 });
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const uniqueSymbols = Array.from(new Set(cards.map(c => c.symbol))).join(' ');
      const flipTool = { name: 'flipCardBySymbol', parameters: { type: Type.OBJECT, properties: { symbol: { type: Type.STRING } }, required: ['symbol'] } };
      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        callbacks: {
          onopen: () => {
            setIsVoiceActive(true);
            const source = inputCtx.createMediaStreamSource(stream);
            const script = inputCtx.createScriptProcessor(4096, 1, 1);
            script.onaudioprocess = (e) => {
              const data = e.inputBuffer.getChannelData(0);
              const int16 = new Int16Array(data.length);
              for (let i = 0; i < data.length; i++) int16[i] = data[i] * 32768;
              sessionPromise.then(s => s.sendRealtimeInput({ media: { data: encode(new Uint8Array(int16.buffer)), mimeType: 'audio/pcm;rate=16000' } }));
            };
            source.connect(script); script.connect(inputCtx.destination);
          },
          onmessage: async (msg) => {
            if (msg.serverContent?.inputTranscription) setTranscription(msg.serverContent.inputTranscription.text);
            if (msg.toolCall) {
              msg.toolCall.functionCalls.forEach(fc => {
                if (fc.name === 'flipCardBySymbol') {
                  const sym = fc.args.symbol;
                  const idx = cardsRef.current.findIndex(c => c.symbol === sym && !c.isFlipped && !c.isMatched);
                  if (idx !== -1) handleCardClick(idx);
                  sessionPromise.then(s => s.sendToolResponse({ functionResponses: { id: fc.id, name: fc.name, response: { result: "ok" } } }));
                }
              });
            }
            const b64 = msg.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            if (b64) {
              const buf = await decodeAudioData(decode(b64), outputCtx, 24000, 1);
              const node = outputCtx.createBufferSource();
              node.buffer = buf; node.connect(outputCtx.destination);
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, outputCtx.currentTime);
              node.start(nextStartTimeRef.current);
              nextStartTimeRef.current += buf.duration;
            }
          }
        },
        config: { responseModalities: [Modality.AUDIO], tools: [{ functionDeclarations: [flipTool] }], systemInstruction: \`Assistant for memory game. Symbols: \${uniqueSymbols}. Use tool when user names emoji.\` }
      });
      sessionRef.current = await sessionPromise;
    } catch (e) { setIsVoiceActive(false); }
  };

  return (
    <div className="min-h-screen p-4 flex flex-col items-center">
      {gameState === 'menu' ? <Menu onStart={startGame} difficulty={difficulty} setDifficulty={setDifficulty} category={category} setCategory={setCategory} /> :
       gameState === 'won' ? <ResultModal stats={stats} onPlayAgain={startGame} onBack={() => { setGameState('menu'); stopVoice(); }} /> :
       <div className="w-full max-w-4xl flex flex-col items-center">
         <StatsPanel stats={stats} onRestart={startGame} onToggleVoice={isVoiceActive ? stopVoice : startVoice} isVoiceActive={isVoiceActive} />
         <div className="grid gap-4 w-full" style={{ gridTemplateColumns: \`repeat(\${LEVEL_CONFIGS[difficulty].cols}, 1fr)\` }}>
           {cards.map((c, i) => <Card key={c.id} card={c} onClick={() => handleCardClick(i)} />)}
         </div>
         <VoiceOverlay transcription={transcription} isActive={isVoiceActive} />
       </div>}
    </div>
  );
};
export default App;