import { Difficulty } from './types';
export const LEVEL_CONFIGS = {
  [Difficulty.EASY]: { rows: 2, cols: 3 },
  [Difficulty.MEDIUM]: { rows: 3, cols: 4 },
  [Difficulty.HARD]: { rows: 4, cols: 5 }
};
export const EMOJI_SETS = {
  ANIMALS: ['🐶', '🐱', '🐭', '🐹', '🐰', '🦊', '🐻', '🐼', '🐨', '🐯'],
  FRUITS: ['🍎', '🍌', '🍉', '🍇', '🍓', '🍍', '🥝', '🍒', '🍑', '🍐'],
  NUMBERS: ['0️⃣', '1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣'],
  ALPHABETS: ['🇦', '🇧', '🇨', '🇩', '🇪', '🇫', '🇬', '🇭', '🇮', '🇯'],
  FOOD: ['🍔', '🍕', '🌮', '🍣', '🍦', '🍩', '🍿', '🥨', '🥐', '🥟'],
  VEHICLES: ['🚗', '🚕', '🚲', '🚀', '🚁', '🚜', '🏎️', '🚢', '🚂', '🛹'],
  SPORTS: ['⚽', '🏀', '🎾', '🏐', '🏈', '⚾', '🎱', '🥊', '🥋', '⛳']
};