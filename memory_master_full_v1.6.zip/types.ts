export enum Difficulty { EASY = 'EASY', MEDIUM = 'MEDIUM', HARD = 'HARD' }
export enum GameMode { NORMAL = 'NORMAL', TIMED = 'TIMED' }
export interface CardData { id: string; symbol: string; isFlipped: boolean; isMatched: boolean; pairId: number; }
export interface GameStats { score: number; attempts: number; timeSeconds: number; matches: number; totalPairs: number; }