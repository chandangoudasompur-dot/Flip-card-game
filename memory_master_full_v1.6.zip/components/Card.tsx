import React from 'react';
export default ({ card, onClick }: any) => {
  const shown = card.isFlipped || card.isMatched;
  return (
    <div className="relative aspect-square perspective-1000 cursor-pointer" onClick={onClick}>
      <div className={`w-full h-full duration-500 preserve-3d transition-transform ${shown ? 'rotate-y-180' : ''}`}>
        <div className="absolute inset-0 backface-hidden flex items-center justify-center bg-white border-4 border-indigo-200 rounded-xl shadow-md">
          <i className="fa-solid fa-brain text-indigo-300 text-3xl"></i>
        </div>
        <div className={`absolute inset-0 backface-hidden rotate-y-180 flex items-center justify-center rounded-xl border-4 ${card.isMatched ? 'bg-green-50 border-green-400' : 'bg-white border-indigo-500'}`}>
          <span className="text-4xl">{card.symbol}</span>
        </div>
      </div>
    </div>
  );
};