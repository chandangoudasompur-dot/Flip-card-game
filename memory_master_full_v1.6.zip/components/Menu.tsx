import React, { useState } from 'react';
import { EMOJI_SETS } from '../constants';

export default ({ onStart, difficulty, setDifficulty, category, setCategory, onDownload }: any) => (
    <div className="bg-white rounded-3xl p-8 max-w-md w-full shadow-2xl space-y-6 animate-fade-in text-center">
        <div className="w-20 h-20 bg-indigo-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
          <i className="fa-solid fa-brain text-4xl text-indigo-600"></i>
        </div>
        <h1 className="text-3xl font-black text-indigo-600">Memory Master</h1>
        <p className="text-gray-400 text-sm font-medium">Train your brain, even with your voice!</p>
        <div className="space-y-4">
          <label className="text-xs font-bold uppercase text-gray-400 tracking-widest mb-2 block">Level Difficulty</label>
          <div className="grid grid-cols-3 gap-2">
            {['EASY', 'MEDIUM', 'HARD'].map(d => (
              <button key={d} onClick={() => setDifficulty(d)} className={`p-3 rounded-xl border-2 font-black transition-all text-sm ${difficulty === d ? 'bg-indigo-600 text-white border-indigo-600 shadow-lg' : 'bg-white text-gray-400 border-gray-100'}`}>{d}</button>
            ))}
          </div>
          <label className="text-xs font-bold uppercase text-gray-400 tracking-widest mb-2 block pt-2">Category</label>
          <div className="grid grid-cols-2 gap-2 max-h-32 overflow-y-auto pr-1">
            {Object.keys(EMOJI_SETS).map(c => (
              <button key={c} onClick={() => setCategory(c)} className={`p-2 rounded-xl border-2 font-black transition-all text-xs ${category === c ? 'bg-indigo-600 text-white border-indigo-600 shadow-lg' : 'bg-white text-gray-400 border-gray-100'}`}>{c}</button>
            ))}
          </div>
        </div>
        <div className="pt-4 space-y-3">
            <button onClick={onStart} className="w-full bg-indigo-600 text-white py-4 rounded-2xl font-black text-xl shadow-xl transition-all flex items-center justify-center gap-3">
                <i className="fa-solid fa-play"></i> START GAME
            </button>
            <button onClick={onDownload} className="w-full bg-emerald-500 text-white py-3 rounded-2xl font-bold text-sm shadow-lg transition-all flex items-center justify-center gap-2">
                <i className="fa-solid fa-android"></i> PREPARE APK BUNDLE
            </button>
        </div>
    </div>
);